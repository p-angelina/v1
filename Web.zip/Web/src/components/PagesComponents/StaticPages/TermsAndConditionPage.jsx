"use client"
import TermsAndCondition from '@/components/StaticPages/TermsAndCondition'

const TermsAndConditionPage = () => {
  return (
    <><TermsAndCondition /></>
  )
}

export default TermsAndConditionPage