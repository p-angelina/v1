"use client"
import AboutUs from '@/components/StaticPages/AboutUs'

const AboutaUsPage = () => {
  return (
    <><AboutUs /></>
  )
}

export default AboutaUsPage