"use client"
import AllCaetgories from '@/components/Caetgories/AllCaetgories'
import React from 'react'

const AllCategoriesPage = () => {
  return (
    <>
    <AllCaetgories />
    </>
  )
}

export default AllCategoriesPage