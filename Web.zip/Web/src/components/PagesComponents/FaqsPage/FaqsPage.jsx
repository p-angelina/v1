
import React from 'react'
import Faqs from './Faqs'

const FaqsPage = () => {
  return (
   <>
   <Faqs />
   </>
  )
}

export default FaqsPage