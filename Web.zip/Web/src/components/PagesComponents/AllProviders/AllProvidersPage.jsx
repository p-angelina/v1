"use client"
import AllProviders from '@/components/AllProviders/AllProviders'
import React from 'react'

const AllProvidersPage = () => {
  return (
    <>
    <AllProviders />
    </>
  )
}

export default AllProvidersPage