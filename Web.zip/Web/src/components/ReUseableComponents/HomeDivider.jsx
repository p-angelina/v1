import React from "react";

const HomeDivider = () => {
  return <div className="light_bg_color h-[24px]"></div>;
};

export default HomeDivider;
